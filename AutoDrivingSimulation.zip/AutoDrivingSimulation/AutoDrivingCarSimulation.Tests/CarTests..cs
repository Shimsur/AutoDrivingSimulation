using Xunit;
using AutoDrivingCarSimulation;

namespace AutoDrivingCarSimulation.Tests
{
    public class CarTests
    {
        [Fact]
        public void Car_TurnLeft_ChangesDirectionCorrectly()
        {
            var car = new Car("TestCar", 1, 1, Direction.N, "L");
            car.ExecuteCommand('L', 5, 5);
            Assert.Equal(Direction.W, car.Facing);
        }

        [Fact]
        public void Car_TurnRight_ChangesDirectionCorrectly()
        {
            var car = new Car("TestCar", 1, 1, Direction.N, "R");
            car.ExecuteCommand('R', 5, 5);
            Assert.Equal(Direction.E, car.Facing);
        }

        [Fact]
        public void Car_MoveForward_UpdatesPositionCorrectly()
        {
            var car = new Car("TestCar", 1, 1, Direction.N, "F");
            car.ExecuteCommand('F', 5, 5);
            Assert.Equal(2, car.Y); // Expect Y to increase since facing North
        }

        [Fact]
        public void Car_DoesNotMoveBeyondBoundary()
        {
            var car = new Car("TestCar", 0, 0, Direction.S, "F");
            car.ExecuteCommand('F', 5, 5);
            Assert.Equal(0, car.Y); // Should not move outside boundary
        }
    }
}
