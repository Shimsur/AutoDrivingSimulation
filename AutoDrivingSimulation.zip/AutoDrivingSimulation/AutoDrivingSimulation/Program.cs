﻿using System;
using System.Collections.Generic;

namespace AutoDrivingCarSimulation
{
    public enum Direction { N, E, S, W }

    public class Car
    {
        public string Name { get; }
        public int X { get; private set; }
        public int Y { get; private set; }
        public Direction Facing { get; private set; }
        public string Commands { get; }

        private static readonly Dictionary<Direction, (int dx, int dy)> Moves = new()
        {
            { Direction.N, (0, 1) },
            { Direction.E, (1, 0) },
            { Direction.S, (0, -1) },
            { Direction.W, (-1, 0) }
        };

        public Car(string name, int x, int y, Direction facing, string commands)
        {
            Name = name;
            X = x;
            Y = y;
            Facing = facing;
            Commands = commands;
        }

        public void ExecuteCommand(char command, int width, int height)
        {
            switch (command)
            {
                case 'L': Facing = (Direction)(((int)Facing + 3) % 4); break;
                case 'R': Facing = (Direction)(((int)Facing + 1) % 4); break;
                case 'F':
                    int newX = X + Moves[Facing].dx;
                    int newY = Y + Moves[Facing].dy;
                    if (newX >= 0 && newX < width && newY >= 0 && newY < height)
                    {
                        X = newX;
                        Y = newY;
                    }
                    break;
            }
        }
    }

    class Program
    {
        static void Main()
        {
            Console.WriteLine("Welcome to Auto Driving Car Simulation!");
            Console.Write("Please enter the width and height of the simulation field in x y format: ");
            var fieldSize = Console.ReadLine().Split(' ');
            int width = int.Parse(fieldSize[0]);
            int height = int.Parse(fieldSize[1]);
            Console.WriteLine($"You have created a field of {width} x {height}.");

            List<Car> cars = new List<Car>();
            while (true)
            {
                Console.WriteLine("Please choose from the following options:");
                Console.WriteLine("[1] Add a car to field");
                Console.WriteLine("[2] Run simulation");
                Console.Write("Enter option: ");
                int option = int.Parse(Console.ReadLine());

                if (option == 1)
                {
                    Console.Write("Please enter the name of the car: ");
                    string name = Console.ReadLine();
                    Console.Write("Please enter initial position of car in x y Direction format: ");
                    var input = Console.ReadLine().Split(' ');
                    int x = int.Parse(input[0]);
                    int y = int.Parse(input[1]);
                    Direction facing = Enum.Parse<Direction>(input[2]);
                    Console.Write("Please enter the commands for the car: ");
                    string commands = Console.ReadLine().ToUpper();
                    cars.Add(new Car(name, x, y, facing, commands));
                }
                else if (option == 2)
                {
                    foreach (var car in cars)
                    {
                        foreach (char cmd in car.Commands)
                        {
                            car.ExecuteCommand(cmd, width, height);
                        }
                        Console.WriteLine($"- {car.Name}, ({car.X},{car.Y}) {car.Facing}");
                    }
                    break;
                }
            }
        }
    }
}
